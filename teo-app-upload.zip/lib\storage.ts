import type { DayRecord } from './types';

function createEmptyDay(date: string): DayRecord {
  const emptyExercises = {
    ex1: { done: false, time: null, stars: 0 },
    ex2: { done: false, time: null, stars: 0 },
    ex3: { done: false, time: null, stars: 0 },
  };
  const emptyFruit = { done: false, time: null, fruits: [], stars: 0 };

  return {
    date,
    lastUpdated: new Date().toISOString(),
    morning: {
      medicines: {
        kollis: { done: false, time: null },
        ferro: { done: false, time: null },
        vitaminaD: { done: false, time: null },
      },
      water: { ml: null, time: null },
      fruit: { ...emptyFruit },
      exercises: { ...emptyExercises },
    },
    afternoon: {
      lunch: { done: false, time: null, stars: 0 },
      water: { ml: null, time: null },
      fruit: { ...emptyFruit },
      exercises: { ...emptyExercises },
    },
  };
}

const memStore = new Map<string, DayRecord>();

function isKvConfigured() {
  return !!process.env.KV_REST_API_URL;
}

export async function getDay(date: string): Promise<DayRecord> {
  if (isKvConfigured()) {
    const { kv } = await import('@vercel/kv');
    const record = await kv.get<DayRecord>(`teo:daily:${date}`);
    return record ?? createEmptyDay(date);
  }
  return memStore.get(date) ?? createEmptyDay(date);
}

export async function saveDay(date: string, record: DayRecord): Promise<void> {
  if (isKvConfigured()) {
    const { kv } = await import('@vercel/kv');
    await kv.set(`teo:daily:${date}`, record);
    return;
  }
  memStore.set(date, record);
}

export async function listDays(): Promise<string[]> {
  if (isKvConfigured()) {
    const { kv } = await import('@vercel/kv');
    const keys = await kv.keys('teo:daily:*');
    return keys
      .map((k: string) => k.replace('teo:daily:', ''))
      .sort()
      .reverse();
  }
  return Array.from(memStore.keys()).sort().reverse();
}
